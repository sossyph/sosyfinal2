import os, sys
os.system("pip install sockets")